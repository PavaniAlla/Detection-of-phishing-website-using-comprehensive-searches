from flask import Flask, render_template, request, redirect, url_for
import urllib.parse
import whois
import requests
import re
import pandas as pd

app = Flask(__name__)

# Load phishing and legitimate datasets
phishing_data = pd.read_csv("phishing-urls.csv")
legitimate_data = pd.read_csv("legitimate-urls.csv")

# Check URL against the datasets
def check_against_datasets(url):
    if url in phishing_data['Domain'].values:
        return "High suspicion: URL found in phishing dataset."
    elif url in legitimate_data['Domain'].values:
        return "Low suspicion: URL found in legitimate dataset."
    return None

def check_phishing(url):
    # Check against the datasets
    dataset_result = check_against_datasets(url)
    if dataset_result:
        return dataset_result

    # Extract URL components
    parsed_url = urllib.parse.urlparse(url)
    domain = parsed_url.netloc

    # Check for suspicious URL patterns
    suspicious_patterns = [
        r"[^a-zA-Z0-9\-\.]",  # Non-alphanumeric characters (except hyphens and periods)
        r"login|signin|account",  # Common phishing keywords in subdomains
    ]
    for pattern in suspicious_patterns:
        if re.search(pattern, domain):
            return "Medium suspicion: URL contains suspicious patterns."

    # Check WHOIS information
    try:
        registration_date = whois.whois(domain).creation_date
        if registration_date is None or registration_date.year > 2022:  # Adjust year as needed
            return "Medium suspicion: Recently registered domain."

    except Exception as e:
        pass  # Handle WHOIS lookup errors gracefully

    # Check for website existence using a safe request
    try:
        headers = {'User-Agent': 'Mozilla/5.0'}
        response = requests.head(url, headers=headers)
        if response.status_code not in range(200, 300):
            return "High suspicion: Website unreachable."

    except requests.exceptions.RequestException:
        pass

    # If no red flags raised, indicate possible safety
    return "Safe (likely, but further checks recommended)."

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        url = request.form['url']
        return redirect(url_for('result', url=url))
    return render_template('index.html')

@app.route('/result')
def result():
    url = request.args.get('url', '')
    result = check_phishing(url)
    return render_template('result.html', result=result)

@app.route('/back')
def back():
    return redirect(url_for('index'))

if __name__ == "__main__":
    app.run(debug=True)
